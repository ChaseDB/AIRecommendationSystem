//
// # SimpleServer
//
// A simple chat server using Socket.IO, Express, and Async.
//
var http = require('http');
var path = require('path');

var async = require('async');
var socketio = require('socket.io');
var express = require('express');

//
// ## SimpleServer `SimpleServer(obj)`
//
// Creates a new instance of SimpleServer with the following options:
//  * `port` - The HTTP port to listen on. If `process.env.PORT` is set, _it overrides this value_.
//
var router = express();
var server = http.createServer(router);
var io = socketio.listen(server);

/*
* Create the mysql DB connection here. report errors and stop if found.
* Authors: Dillon B., Derek B.
*/
var mysql = require('mysql');

var con = mysql.createConnection({
  host: "localhost",
  user: "jborden2",
  password: "", 
  database: "ai"
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
});


router.use(express.static(path.resolve(__dirname, 'client')));
var sockets = [];

const NUMMOVIES = 3;
const NUMGAMES = 3;
var genres_games = [];
var genres_movies = [];
const traits = ['Observant', 'Confident', 'Jolly', 'Hardy', 'Aggressive', 'Hasty', 'Lonely', 'Docile', 'Imaginative'];
var defaultTraits = [0, 0, 0, 0, 0, 0, 0, 0, 0];
var apigenres = {
  "Mystery": 9648,
  "Crime": 80,
  "Sci-Fi": 878,
  "Comedy": 35,
  "Superhero": 10751,
  "Adventure": 12,
  "Action-Adventure": 37,
  "Horror": 27,
  "Animation": 16,
  "Fantasy": 14,
  "Thriller": 53,
  "Action-Comedy": 10770,
  "Drama": 18,
  "Action": 28,
  "Romance": 10749
  
};
var genrearray = ["Mystery", "Crime", "Sci-Fi", "Superhero", "Adventure", "Action-Adventure", "Horror", "Comedy", "Animation", "Fantasy", "Thriller", "Drama", "Action", "Action-Comedy", "Romance"];

var users = {};
var usedQuestions = {};
var answeredQuestions = {};

function setUpGenreArrays(){
  var sql = "SELECT * FROM personalities";
  con.query(sql, function(err, result){
    if (err) throw err;
    for (let i=0; i < result.length; i++){
      
       
       // build array of film genres from database
      result[i]['film'].split(",").forEach(function(genre) {
        if(genres_movies.indexOf(genre.trim()) == -1){
          genres_movies = genres_movies.concat(genre.trim());
        }
      });
      
      // build array of game genres from database
      result[i]['game'].split(",").forEach(function(genre) {
        if(genres_games.indexOf(genre.trim()) == -1){
          genres_games = genres_games.concat(genre.trim());
        }
      });
      
    }
  });
  
}


setUpGenreArrays();

const MAX_QUESTIONS = 10;


router.get('/', function(req, res){
  res.sendFile('client/index.html');
});

// use socket.emit() to send to a socket.
// use broadcast to send to all sockets. function.

io.on('connection', function (socket) {
    console.log('user connected');
    setupQuestions(socket);
    //pickStandout(socket);
    sockets.push(socket);
    users[socket.id] = defaultTraits;
    usedQuestions[socket.id] = [];
    answeredQuestions[socket.id] = [];
    
    socket.on('disconnect', function () {
      sockets.splice(sockets.indexOf(socket), 1);
      delete users[socket.id];
      delete usedQuestions[socket.id];
      delete answeredQuestions[socket.id];
    });
    
    socket.on('getStarted', function(){
      
      var q = {};
      var qNum = usedQuestions[socket.id].pop();
      let sql = "";
      sql = "SELECT * FROM questions WHERE id=" + qNum;
      con.query(sql, function(err, result){
        if (err) throw err;
        q['content'] = result[0]['content'];
        sql = "SELECT * FROM answers WHERE questionid=" + qNum;
        con.query(sql, function(err2, result2){
          if (err2) throw err2;
          q['answers'] = [];
          q['ansCount'] = result2.length;
          for (let i=0; i < result2.length; i++){
            q['answers'].push(result2[i]['id']);
            q['ans' + (i+1)] = result2[i]['content'];
          }
          //var question = {'content': 'Another Question Here!', 'ansCount': 3, 'answers': [2, 5, 6], 'ans1': "lol", 'ans2': 'lolol', 'ans3' :'trololol'};
          socket.emit('begin', q);
        });
      });
    });
    
    socket.on('nextQuestion', function(){
      if (answeredQuestions[socket.id].length == MAX_QUESTIONS){
        // analyze results for the end through another f(x)
        computeStats(socket);
        //var results = {};
        
        return;
      }
      // query here
      // while id in usedQuestions[socket.id]{query again}
      var q = {};
      var qNum = usedQuestions[socket.id].pop();
      let sql = "";
      sql = "SELECT * FROM questions WHERE id=" + qNum;
      con.query(sql, function(err, result){
        if (err) throw err;
        q['content'] = result[0]['content'];
        sql = "SELECT * FROM answers WHERE questionid=" + qNum;
        con.query(sql, function(err2, result2){
          if (err2) throw err2;
          q['answers'] = [];
          q['ansCount'] = result2.length;
          for (let i=0; i < result2.length; i++){
            q['answers'].push(result2[i]['id']);
            q['ans' + (i+1)] = result2[i]['content'];
          }
          //var question = {'content': 'Another Question Here!', 'ansCount': 3, 'answers': [2, 5, 6], 'ans1': "lol", 'ans2': 'lolol', 'ans3' :'trololol'};
          socket.emit('question', q);
        });
      });
      
    });
    
    socket.on('myAnswer', function(ans, question){
      //console.log("my answer sends: " + ans + " for: "+ question);
      answeredQuestions[socket.id].push(ans);
      // record results here.
      
    });

  });

function broadcast(event, data) {
  sockets.forEach(function (socket) {
    socket.emit(event, data);
  });
}

function computeStats(socket){
  //answeredQuestions holds answer ids.
  var len = answeredQuestions[socket.id].length;
  var sql = "SELECT * FROM personalities";
  con.query(sql, function(err, personalities){
    if (err) throw err;
    sql = "SELECT * FROM answers";
      con.query(sql, function(err2, answerArray){
        if (err2) throw err2;
        //run through each of the answer ids
        for(var i = 0; i < len; i++){
          //answerArray[answeredQuestions[socket.id][i]-1]
          var addstats = answerArray[answeredQuestions[socket.id][i]-1]["adding"].split(",");
          var substats = answerArray[answeredQuestions[socket.id][i]-1]["subtracting"].split(",");
          //add stats up
          for(var j = 0; j < addstats.length; j++){
            users[socket.id][addstats[j]-1] = users[socket.id][addstats[j]-1]+2;
          }
          //subtract stats
          for(var k = 0; k < substats.length; k++){
            users[socket.id][substats[k]-1] = users[socket.id][substats[k]-1]-1;
          }
        }
        var results = {};
        
        startDecisions(socket);
        results['stats'] = users[socket.id];
        results['traits'] = traits;
        socket.emit('finished', results);
      });

    
  });
  
  

}

function setupQuestions(socket){
    var sql = "SELECT * FROM questions";
    
    con.query(sql, function(err, result){
      if (err) throw err;
      let max = result.length;
      console.log(max);
      for (let i=1; i <= max; i=i+1){
        usedQuestions[socket.id].push(i);
      }
      usedQuestions[socket.id] = shuffle(usedQuestions[socket.id]);
    });
}

/*
* startDecisions(): used to call the functions associated with picking genres
*   based on user trait results.
*
*/
function startDecisions(socket){
  normalize(socket);
  pickStandout(socket);
}

/*
* normalize(): makes all the traits 0 <= x <= inf  and changes them to probabilities
*     for future calculations/decisions.
*
*/
function normalize(socket){
  let runningSum = 0;
  if (Math.min(...users[socket.id]) < 0){
    let num = Math.abs(Math.min(...users[socket.id]));
    for (let i = 0; i < users[socket.id].length; i++){
      users[socket.id][i] += num;
    }
  }

  for (let i=0; i < users[socket.id].length; i++){
      runningSum += users[socket.id][i];
  }
  
  for (let i=0; i < users[socket.id].length; i++){
    users[socket.id][i] = users[socket.id][i] / 1;//parseFloat(runningSum);
  }

}


/*******************************************************************************
 * Neural Network Functionality
 * 
 * ****************************************************************************/
var synaptic = require('synaptic'); // this line is not needed in the browser
var Neuron = synaptic.Neuron,
Layer = synaptic.Layer,
Network = synaptic.Network,
Trainer = synaptic.Trainer,
Architect = synaptic.Architect;
Perceptron.prototype = new Network();
Perceptron.prototype.constructor = Perceptron;

// Globals for neural network //////////////////////////////////////////////////
var MoviePerceptron = new Perceptron(9,15,15);
var GamePerceptron = new Perceptron(9,15,15);
buildNeuralNetwork();
////////////////////////////////////////////////////////////////////////////////



/**
 * Perceptron Prototype Constructor
 * Builds a new neural network given 3 integer values for the number of nodes
 *for each of the three layers.
 **/
function Perceptron(input, hidden, output)
{
	// create the layers
	var inputLayer = new Layer(input);
	var hiddenLayer = new Layer(hidden);
	var outputLayer = new Layer(output);

  hiddenLayer.project(outputLayer);
	// set the layers
	this.set({
		input: inputLayer,
		hidden: hiddenLayer,
		output: outputLayer
	});
}


/**
 * Launched at the startup of the Node server. Builds up newly created global
 * perceptrons(neural networks) MoviePerceptron and GamePerceptron.
 **/
function buildNeuralNetwork(){
  
  String.prototype.trim = function() {
      return this.replace(/^\s+|\s+$/g, "");
  };

  //first, we get the associated genres for each stat
  var sql = "SELECT * FROM personalities";

  console.log(genres_movies);
  //genres_movies = [];
  //genres_games = [];
  con.query(sql, function(err, result){
    if (err) throw err;
    
    // build input layer to hidden layer connections - movies:
    // the input layer is parallel with the personalities array. Input nodes correspond
    // to a personality. MoviePerceptron.inputLayer.neurons()[0] relates to personalities[0].
  
  
    for(var i = 0; i < MoviePerceptron['layers']['input'].neurons().length; i++){
      var genreIndexArray = [];
      result[i]['film'].split(",").forEach(function(genre){
        genreIndexArray.push(genres_movies.indexOf(genre.trim()));
      });
      for(var j = 0; j < MoviePerceptron['layers']['hidden'].neurons().length; j++){
    
        genreIndexArray.sort();
      //  console.log(genreIndexArray);
        var weight = (j ==  genreIndexArray[0]) ? 1 : 0;
        if(weight == 1){
          genreIndexArray.shift();
        }
        MoviePerceptron['layers']['input'].neurons()[i].project(MoviePerceptron['layers']['hidden'].neurons()[j],weight);
      }

    }

    
    // build input layer to hidden layer connections - games:
    // the input layer is parallel with the personalities array. Input nodes correspond
    // to a personality. GamePerceptron.inputLayer.neurons()[0] relates to personalities[0].
  
  
    for(var i = 0; i < GamePerceptron['layers']['input'].neurons().length; i++){
      var genreIndexArray = [];
      result[i]['game'].split(",").forEach(function(genre){
        genreIndexArray.push(genres_games.indexOf(genre.trim()));
      });
      for(var j = 0; j < GamePerceptron['layers']['hidden'].neurons().length; j++){

        genreIndexArray.sort();
        
        var weight = (j ==  genreIndexArray[0]) ? 1 : 0;
        if(weight == 1){
          genreIndexArray.shift();
        }
        GamePerceptron['layers']['input'].neurons()[i].project(GamePerceptron['layers']['hidden'].neurons()[j],weight);
        
      }

    }
    
    
    
    // hidden layer connection to output
    
    // build input layer to hidden layer connections - movies:
    // the input layer is parallel with the personalities array. Input nodes correspond
    // to a personality. MoviePerceptron.inputLayer.neurons()[0] relates to personalities[0].
  
  
    for(var i = 0; i < MoviePerceptron['layers']['hidden'].neurons().length; i++){
      for(var j = 0; j < MoviePerceptron['layers']['output'].neurons().length; j++){
        genreIndexArray.sort();
        var weight = (j ==  i) ? 1 : 0.1;
        MoviePerceptron['layers']['hidden'].neurons()[i].project(MoviePerceptron['layers']['output'].neurons()[j],weight);
      }
    }
    
    
  });
  
  

  console.log("Build Done ---------------------------------------\nTraining...");

  var trainer = new Trainer(MoviePerceptron)
  	
  var trainingSet = [
    {
      input: [Math.floor(Math.random()*40)+4,0,0,0,0,0,0,0,0],
      output: [1,1,1,0,0,0,0,0,0,0,0,0,0,0,0]
    },
    {
      input: [0,Math.floor(Math.random()*40)+4,0,0,0,0,0,0,0],
      output: [0,0,0,1,1,1,1,0,0,0,0,0,0,0,0]
    },
    {
      input: [0,0,Math.floor(Math.random()*40)+4,0,0,0,0,0,0],
      output: [0,0,0,0,0,0,0,1,1,.1,0,0,0,0,0]
    },
    {
      input: [0,0,0,Math.floor(Math.random()*40)+4,0,0,0,0,0],
      output: [0,1,0,0,0,0,0,0,0,0,1,0,0,0,0]
    },
    {
      input: [0,0,0,0,Math.floor(Math.random()*40)+4,0,0,0,0],
      output: [0,0,0,0,0,0,0,0,0,0,1,1,1,0,0]
    },
    {
      input: [0,0,0,0,0,Math.floor(Math.random()*40)+4,0,0,0],
      output: [0,0,0,1,0,0,1,0,0,0,0,0,0,1,0]
    },
    {
      input: [0,0,0,0,0,0,Math.floor(Math.random()*40)+4,0,0],
      output: [0,0,0,0,0,0,0,1,0,.1,0,0,0,0,1]
    },
    {
      input: [0,0,0,0,0,0,0,Math.floor(Math.random()*40)+4,0],
      output: [0,0,0,0,0,0,0,0,0,0,0,0,0,0,1]
    },
    {
      input: [0,0,0,0,0,0,0,0,Math.floor(Math.random()*40)+4],
      output: [0,0,1,0,0,0,0,0,1,.1,0,0,0,0,0]
    }
  ]
  
  
  trainer.train(trainingSet,{
  	rate: .02,
  	iterations: 50000,
  	error: .000004,
  	shuffle: true,
  	log: 1000,
  	cost: Trainer.cost.MSE
  }); 
}


function pickStandout(socket){
  console.log("Activation with " + users[socket.id]);
  

  var activationarray = (MoviePerceptron.activate(users[socket.id]));
  console.log(activationarray);
  testAPIcall(getMax(activationarray), socket);
}

/*
* Credit: https://stackoverflow.com/questions/6274339/how-can-i-shuffle-an-array
* Randomly shuffles contents of a given array
*/
function shuffle(a) {
    var j, x, i;
    for (i = a.length - 1; i > 0; i--) {
        j = Math.floor(Math.random() * (i + 1));
        x = a[i];
        a[i] = a[j];
        a[j] = x;
    }
    return a;
}

/**
 * Returns the index associated with the maximal value of a given array of 
 * numeric values.
 **/
function getMax(arr){
  
  var indexstack = [];
  for(var i = 0; i < arr.length; i++){
    if(arr[i] > arr[indexstack[0]]){
      indexstack.unshift(i);
    }
  }
  return indexstack;
}

server.listen(process.env.PORT || 3000, process.env.IP || "0.0.0.0", function(){
  var addr = server.address();
  console.log("Recommendations listening at", addr.address + ":" + addr.port);
});




function testAPIcall(indexNum, s){
  var topValues = indexNum.sort((a,b) => a>b).slice(0,2);
  indexNum = Math.floor((Math.random() * 2));
  
  console.log(indexNum + "is the index.");
  var genreChoice = apigenres[genrearray[indexNum]];
var options = {
  "method": "GET",
  "hostname": "api.themoviedb.org",
  "port": null,
  "path": "/3/discover/movie?api_key=151420329fbe6a94a98b3fd8fdca9fe1&language=en-US&include_adult=false&sort_by=popularity.desc&release_date.gte=1995-01-01&with_genres=" + genreChoice,
  "headers": {}
};

http.request(options, function(res) {
  let chunks = [];
  console.log('STATUS: ' + res.statusCode);
  console.log('HEADERS: ' + JSON.stringify(res.headers));
  res.setEncoding('utf8');
  res.on('data', function (chunk) {
    chunks.push(chunk);
    //console.log('\n\nBODY: ' + JSON.parse(chunk)['results'][0]['title']);
  });
  
  res.on('end', function(){
    var response = {};
    let finalChunk = "";
    for (let i=0; i<chunks.length; i++){
      console.log('------------------Chunks ' + chunks[i] + "--------------------");
      finalChunk += chunks[i];
    }
    
    let index1 = 0;
    let index2 = 1;
    let index3 = 2;
    
    for (let i=0; i<3;i++){
      
      if (i==0){
        index1 = Math.floor((Math.random() * 8)); 
      }
      if (i==1){
        index2 = Math.floor((Math.random() * 8)); 
      }
      if (i==2){
        index3 = Math.floor((Math.random() * 8)); 
      }
      
      while (index1 == index2 || index1 == index3 || index2 == index3){
        if (i==0){
        index1 = Math.floor((Math.random() * 8)); 
      }
      if (i==1){
        index2 = Math.floor((Math.random() * 8)); 
      }
      if (i==2){
        index3 = Math.floor((Math.random() * 8)); 
      }
      }
      
    }
    
    Math.floor((Math.random() * 8))
    
    response["movie1"] = JSON.parse(finalChunk)['results'][index1];
    response["movie2"] = JSON.parse(finalChunk)['results'][index2];
    response["movie3"] = JSON.parse(finalChunk)['results'][index3];
    s.emit('finalResults', response);
  });
}).end();

//http://image.tmdb.org/t/p/w342/ <-- image url append on 'poster_path'
}
