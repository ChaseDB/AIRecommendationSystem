function getStarted(){
    socket.emit('getStarted');
}

function closeGraph(){
    console.log('closing graph...');
    document.getElementById('chartContainer').style.display = "none";
    document.getElementById('shader').style.display = "none";
}

function openGraph(){
    console.log('opening graph...');
    document.getElementById('chartContainer').style.display = "block";
    document.getElementById('shader').style.display = "block";
}

var currentQuestion = null;

socket.on('begin', function(question){
   document.getElementById('starting').style.display = "none";
   document.getElementById('quiz').style.display = "block";
   
   var questionText = document.getElementById('questionText');
   var answers = document.getElementById('answers');
   
   //questionText.innerHTML = "I'm a new question!!!";
   questionText.innerHTML = question['content'];
   answers.innerHTML = "";
   for (var i =0; i < question['ansCount']; i=i+1){
       answers.innerHTML += "<button onclick='answerQuestion(this.id)' class='ansbutton' id='"+ question['answers'][i] +"'>" + question['ans' + (i + 1)] + "</button>";
   }
   currentQuestion = question;
});

socket.on('question', function(question){
     currentQuestion = question;
   var questionText = document.getElementById('questionText');
   var answersSec = document.getElementById('answers');
   //questionText.innerHTML = "I'm a new question!!!";
   questionText.innerHTML = question['content'];
   answersSec.innerHTML = "";
   for (var i =0; i < question['ansCount']; i=i+1){
       answersSec.innerHTML += "<button onclick='answerQuestion(this.id)' class='ansbutton' id='"+ question['answers'][i] +"'>" + question['ans' + (i + 1)] + "</button>";
   }
});

socket.on('finished', function(results){
   let start = document.getElementById('starting');
   let quiz = document.getElementById('quiz');
   let finish = document.getElementById('finished');
   let closingText = document.getElementById('closingText');
   let chart = document.getElementById('chartContainer');
   
   loadGraph(results);
   start.style.display = "none";
   quiz.style.display = "none";
   
   finished.style.display = "block";
   
});

socket.on('finalResults', function(results){
    let movie1pic = document.getElementById('movie1');
    let movie2pic = document.getElementById('movie2');
    let movie3pic = document.getElementById('movie3');
    
    let movie1title = document.getElementById('movie1Title');
    let movie2title = document.getElementById('movie2Title');
    let movie3title = document.getElementById('movie3Title');

    movie1pic.src = "http://image.tmdb.org/t/p/w342/" + results['movie1']['poster_path'];
    movie2pic.src = "http://image.tmdb.org/t/p/w342/" + results['movie2']['poster_path'];
    movie3pic.src = "http://image.tmdb.org/t/p/w342/" + results['movie3']['poster_path'];
    
    movie1title.innerHTML = results['movie1']['title'];
    movie2title.innerHTML = results['movie2']['title'];
    movie3title.innerHTML = results['movie3']['title'];
    
    movie1title.onclick = function(){
        window.open('https://www.google.com/search?q=' + movie1title.innerHTML +'');
    };
    
    movie2title.onclick = function(){
        window.open('https://www.google.com/search?q=' + movie2title.innerHTML +'');
    };
    
    movie3title.onclick = function(){
        window.open('https://www.google.com/search?q=' + movie3title.innerHTML +'');
    };
    
    movie1pic.onclick = function(){
        window.open('https://www.google.com/search?q=' + movie1title.innerHTML +'');
    };
    
    movie2pic.onclick = function(){
        window.open('https://www.google.com/search?q=' + movie2title.innerHTML +'');
    };
    
    movie3pic.onclick = function(){
        window.open('https://www.google.com/search?q=' + movie3title.innerHTML +'');
    };
         
    
});

function loadGraph(r){
    	
var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: true,
	
	title:{
		text:"Personality Traits and Probabilities"
	},
	axisX:{
		interval: 1
	},
	axisY2:{
		interlacedColor: "rgba(1,77,101,.2)",
		gridColor: "rgba(1,77,101,.1)",
		title: "Probabilities"
	},
	data: [{
		type: "bar",
		name: "Traits",
		axisYType: "secondary",
		color: "#014D65",
		dataPoints: [
			{ y: r['stats'][0], label: r['traits'][0] },
			{ y: r['stats'][1], label: r['traits'][1] },
			{ y: r['stats'][2], label: r['traits'][2] },
			{ y: r['stats'][3], label: r['traits'][3] },
			{ y: r['stats'][4], label: r['traits'][4] },
			{ y: r['stats'][5], label: r['traits'][5] },
			{ y: r['stats'][6], label: r['traits'][6] },
			{ y: r['stats'][7], label: r['traits'][7] },
			{ y: r['stats'][8], label: r['traits'][8] }
		]
	}]
});
chart.render();

}

function answerQuestion(id){
    socket.emit('myAnswer', id, currentQuestion);
    socket.emit('nextQuestion');
}
